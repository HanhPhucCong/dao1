public class main {
    public static void main(String[] args) {
        ProductFactory productFactory;
        Product product;
        productFactory = new CocaColaFactory();
        product = new CocaCola();

    }
}
