public class Customization {
    private double extraMilk;
    private double sugar;
    private double mugSize;

    public Customization(double extraMilk, double sugar, double mugSize) {
        this.extraMilk = extraMilk;
        this.sugar = sugar;
        this.mugSize = mugSize;
    }
}
