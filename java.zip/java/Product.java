public interface Product {
    public void make();
}
