public abstract class ProductFactory {
    public abstract Product getProduct(Customization customization);

    public static ProductFactory getProductFactory() {
        return null;
    }
}
