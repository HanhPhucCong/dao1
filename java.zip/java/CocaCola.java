public class CocaCola implements Product {
    private Customization cust;
    private Preparation prep;

    public CocaCola(Customization cust, Preparation prep) {
        this.cust = cust;
        this.prep = prep;
    }

    public CocaCola() {

    }

    @Override
    public void make() {

    }

    public void setWater() {

    }

    public void setCoke() {

    }
}
