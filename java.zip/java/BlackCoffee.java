public class BlackCoffee implements Product {
    private Customization cust;
    private Preparation prep;

    public BlackCoffee(Customization cust, Preparation prep) {
        this.cust = cust;
        this.prep = prep;
    }
    @Override
    public void make() {
        System.out.println("Making black coffee");
    }

    public void setWater() {

    }

    public void setCoffee() {

    }
}
