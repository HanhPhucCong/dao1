public class LemonadeFactory extends ProductFactory {
    @Override
    public Product getProduct(Customization customization) {
        return null;
    }
}
