public class HotMilk implements Product {
    private Customization cust;
    private Preparation prep;

    public HotMilk(Customization cust, Preparation prep) {
        this.cust = cust;
        this.prep = prep;
    }

    @Override
    public void make() {

    }

    public void setMilk() {

    }
}
