public class BlackCoffeeFactory extends ProductFactory {
    @Override
    public Product getProduct(Customization customization) {
        return null;
    }
}
