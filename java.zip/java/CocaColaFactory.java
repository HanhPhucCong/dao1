public class CocaColaFactory extends ProductFactory {
    @Override
    public Product getProduct(Customization customization) {
        return null;
    }
}
