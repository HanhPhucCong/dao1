public class CappuccinoFactory extends ProductFactory {
    @Override
    public Product getProduct(Customization customization) {
        return null;
    }
}
