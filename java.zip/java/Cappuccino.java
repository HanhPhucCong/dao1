public class Cappuccino implements Product {
    private Customization cust;
    private Preparation prep;

    public Cappuccino(Customization cust, Preparation prep) {
        this.cust = cust;
        this.prep = prep;
    }

    @Override
    public void make() {
        System.out.println("Making Cappuccino");
    }

    public void setMilk() {

    }

    public void setSugar() {

    }

    public void setCoffee() {

    }
}
