public class Lemonade implements Product {
    private Customization cust;
    private Preparation prep;

    public Lemonade(Customization cust, Preparation prep) {
        this.cust = cust;
        this.prep = prep;
    }

    @Override
    public void make() {

    }

    public void setWater() {

    }

    public void setSugar() {

    }

    public void setLemonJuice() {

    }
}
