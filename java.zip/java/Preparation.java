public class Preparation {
    private double milk;
    private double water;
    private double sugar;
    private double coke;
    private double liquidCoffee;
    private double addedFlavour;
    private double tea;

    public Preparation(double milk, double water, double sugar, double coke, double liquidCoffee, double addedFlavour, double tea) {
        this.milk = milk;
        this.water = water;
        this.sugar = sugar;
        this.coke = coke;
        this.liquidCoffee = liquidCoffee;
        this.addedFlavour = addedFlavour;
        this.tea = tea;
    }
}
