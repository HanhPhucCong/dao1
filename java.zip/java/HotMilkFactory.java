public class HotMilkFactory extends ProductFactory {
    @Override
    public Product getProduct(Customization customization) {
        return null;
    }
}
